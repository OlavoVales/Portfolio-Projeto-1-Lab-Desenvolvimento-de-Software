import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Footer } from '../footer/footer';

@Component({
  selector: 'app-footer',
  imports: [RouterModule, Footer],
  templateUrl: './contato.html',
  styleUrl: './contato.css'
})
export class Contato {

}